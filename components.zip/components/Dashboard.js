import React,{Component} from 'react';
import { StyleSheet,  View, Image, ImageBackground,TouchableOpacity,ScrollView } from 'react-native';
import { createAppContainer } from 'react-navigation';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import { Container, Header, Content, Card, CardItem, Thumbnail, Text, Button, Left, Body, Right,Title} from 'native-base';
import firebase from 'react-native-firebase';
import { responsiveWidth, responsiveHeight} from 'react-native-responsive-dimensions';
import Icon from 'react-native-vector-icons/FontAwesome';  
import Cart from './Cart';
import Categories from './Categories';
import Order from './Order';



class CustomHeader extends Component {
  state ={
    Email:'',
    displayname:''
 }
 componentDidMount(){
   const {Email,displayname}  = firebase.auth().currentUswe;
   this.setState({Email,displayname });
 }

signOutUser =() =>{
  firebase.auth().signOut();
}

  constructor(props){ 
    super(props);
    this.state={

    };
  }
  
  render(){
    return (
      
      <Header headerTintColor='red'>
        <Left>
          <TouchableOpacity  onPress={() => this.props.navigation.OpenDrawer()}>
            <Icon name="bars" size={30} color="white"  />
          </TouchableOpacity>
        </Left>
        <Body>
          <Title >Header</Title>
        </Body>
        <Right>
          <Button transparent>
            <Icon name='arrow-right' size={20} color="white" />
          </Button>
        </Right>
      </Header>
    



      );
    }
    }

class Dashboard extends Component {
  
static navigationOptions = {
  drawerLabel: 'Home',
}
  render(){
    return (



      
    <View style={styles.container}>

<CustomHeader/>
      <ScrollView>
      
     <View> 
           
       
     <Container>
        
        <Content>
          <Card >
            
            <CardItem cardBody onPress={() => this.props.navigation.navigate('Cart')}>
            <TouchableOpacity
        onPress={() => this.props.navigation.navigate('Cart')} >
              <Image source={require('./img/food.jpg')} style={{height:responsiveHeight(24), width:responsiveWidth(99), flex: 1}}/>
           </TouchableOpacity>
            </CardItem>
            
            
            <CardItem>
              
              <Body >
                <TouchableOpacity onPress={() => this.props.navigation.navigate('Cart')}>
                  <Text style={styles.innerText}>COOKING</Text>
                </TouchableOpacity>
              </Body>
              
            </CardItem>
            </Card>
            <Card>
            <CardItem cardBody>
            <TouchableOpacity
        onPress={() => this.props.navigation.navigate('Cart')} >
              <Image source={require('./img/sketching.jpg')} style={{height:responsiveHeight(24), width:responsiveWidth(99), flex: 1}}/>
           </TouchableOpacity>
            </CardItem>
            <CardItem>
              
              <Body>
                
              <TouchableOpacity onPress={() => this.props.navigation.navigate('Order')}>
                  <Text  style={styles.innerText}>SKETCHING</Text>
                </TouchableOpacity>
              </Body>
              
            </CardItem>

            </Card>
            <Card>
            <CardItem cardBody>
            <TouchableOpacity
        onPress={() => this.props.navigation.navigate('Cart')} >
              <Image source={require('./img/baking.jpg')} style={{height:responsiveHeight(24), width:responsiveWidth(99), flex: 1}}/>
           </TouchableOpacity>
            </CardItem>
            <CardItem>
              
              <Body>
               <TouchableOpacity onPress={() => this.props.navigation.navigate('Categories')}>
                
                  <Text  style={styles.innerText}>BAKING</Text>
                </TouchableOpacity>
              </Body>
              
            </CardItem>


          </Card>
        </Content>
      </Container>

</View>

</ScrollView>

    </View>
  );
}
}


const TabNavigator = createBottomTabNavigator({
  Dashboard:{  
    screen:Dashboard,  
    navigationOptions:{  
      tabBarLabel:'Home',  
      tabBarIcon:({tintColor})=>(  
          <Icon name="home" color={tintColor} size={25}/>  
      )  
    }  
  },  
  Order:{  
    screen:Order,  
    navigationOptions:{  
      tabBarLabel:'Inbox',  
      tabBarIcon:({tintColor})=>(  
          <Icon name="inbox" color={tintColor} size={25}/>  
      )  
    }  
  },  

  Cart:{  
    screen:Cart,  
    navigationOptions:{  
      tabBarLabel:'Cart',  
      tabBarIcon:({tintColor})=>(  
          <Icon name="shopping-cart" color={tintColor} size={25}/>  
      )  
    }  
  },
  Categories:{  
    screen:Categories,  
    navigationOptions:{  
      tabBarLabel:'Profile',  
      tabBarIcon:({tintColor})=>(  
          <Icon name="user-circle" color={tintColor} size={25}/>  
      )  
    }  
  },
});




const styles = StyleSheet.create({
  container: {
    flex: 1,
    
    
  },


  food:{
    borderWidth : 1,
    borderColor : 'white',
    backgroundColor : 'white',
    paddingLeft : 150,
    fontWeight : 'bold' 
  },

  innerText:{
    paddingLeft : 160
  }
});
export default createAppContainer(TabNavigator);