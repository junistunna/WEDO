import React,{Component} from 'react';
import { StyleSheet,  View, Image, ImageBackground,TouchableOpacity, } from 'react-native';
import { Container, Header, Left, Body, Right, Button, Icon, Title,Text } from 'native-base';
import CustomHeader from './Dashboard'




export default class Categories extends Component {
  
static navigationOptions = {
  drawerLabel: 'Categories',
}
  render(){
    return (
    <View style={styles.container}>
       <Header>
        <Left>
          <Button transparent>
            <Icon name='arrow-back' />
          </Button>
        </Left>
        <Body>
          <Title>Header</Title>
        </Body>
        <Right>
          <Button transparent>
            <Icon name='menu' />
          </Button>
        </Right>
      </Header>
     <View> 
      <ImageBackground source = {require('./img/background.png')} style={{width: '100%', height: '100%'}} >
      
       
      <TouchableOpacity onPress = {()  => this.props.navigation.navigator('Card1')}>  
      
      <Text> Order details </Text>
       </TouchableOpacity>
      


      </ImageBackground>
</View>
    </View>
  );
}
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    
    
  },


  food:{
    borderWidth : 1,
    borderColor : 'white',
    backgroundColor : 'white',
    paddingLeft : 150,
    fontWeight : 'bold' 
  }
});
