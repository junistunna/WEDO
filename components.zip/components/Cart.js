import React,{Component} from 'react';
import { StyleSheet,  View, Image, ImageBackground,TouchableOpacity, } from 'react-native';
import { Container, Header, Left, Body, Right, Button, Icon, Title,Text ,Content,Card,CardItem,Thumbnail} from 'native-base';
import CustomHeader from './Dashboard'




export default class Cart extends Component {
  render(){
    return (
    <View style={styles.container}>
      <Header style={styles.Head}>
        <Left>
          <Button transparent>
            <Icon name='arrow-back' />
          </Button>
        </Left>
        <Body>
          <Title>Header</Title>
        </Body>
        <Right>
          <Button transparent>
            <Icon name='menu' />
          </Button>
        </Right>
      </Header>
     <View> 
      <ImageBackground source = {require('./img/background.png')} style={{width: '100%', height: '100%'}} >
      
       
          <Card>
            
            <CardItem cardBody>
            </CardItem>
            <CardItem>
              
              
                <Button transparent>
                  <Icon active name="chatbubbles" />
                  <Text>Cooking</Text>
                </Button>
            
            
            </CardItem>
          </Card>



        
          <Card>
            
            <CardItem cardBody>
            </CardItem>
            <CardItem>
              
              
                <Button transparent>
                  <Icon active name="chatbubbles" />
                  <Text>Sketching</Text>
                </Button>
            
            
            </CardItem>
          </Card>



          <Card>
            
            <CardItem cardBody>
            </CardItem>
            <CardItem>
              
              
                <Button transparent>
                  <Icon active name="chatbubbles" />
                  <Text>Baking</Text>
                </Button>
            
            
            </CardItem>
          </Card>

      </ImageBackground>
</View>
    </View>




  );
}
}














const styles = StyleSheet.create({
  container: {
    flex: 1,
    
    
  },
  Head:{
    backgroundColor:'black'
  },


  food:{
    borderWidth : 1,
    borderColor : 'white',
    backgroundColor : 'white',
    paddingLeft : 150,
    fontWeight : 'bold' 
  },
  
});
