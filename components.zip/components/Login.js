import React,{Component} from 'react';
import { StyleSheet,
    Text,
    View ,
    TextInput,submitButton,
   TouchableOpacity,
   Image,
   ImageBackground,
   Button
} from 'react-native';

import {TextField,OutlinedTextField,} from 'react-native-material-textfield';
import { TextButton, RaisedTextButton } from 'react-native-material-buttons';
import { ScrollView } from 'react-native-gesture-handler';
import firebase from 'react-native-firebase';

import { responsiveWidth, responsiveHeight} from 'react-native-responsive-dimensions';



export default class Login extends Component {
state ={
   Email:'',
   password:''
}

handleLogin = () =>{
   const{Email,password} =this.state
   firebase.auth().signInWithEnailAndPassword(Email,password)
}
  



 render() {
    return (
      
       <View style = {styles.container}>

    
     <ScrollView>
    <Image source = {require('./img/logo.png')} style={{height:responsiveHeight(8), width:responsiveWidth(55), marginLeft:100,marginTop:35  }} />   
          
          <Text style = {styles.loginForm}>LOGIN</Text>

          <View style = {styles.username}>
      <OutlinedTextField style = {styles.inputfield}

        label='Email'
        keyboardType='key-pad'
        tintColor = '#BE1E2D'
        onChangeText ={Email  => this.setState({Email})}
        value ={this.state.Email}
        
        
        
      />
</View> 

<View style = {styles.password}>
<OutlinedTextField style = {styles.inputfield}

label='Password'
keyboardType='key-pad'
tintColor = '#BE1E2D'
secureTextEntry={true}
onChangeText ={password  => this.setState({password})}
value ={this.state.password}

/>
</View>

<View style = {styles.button}>

<RaisedTextButton  
 onPress = {this.handleLogin}
title='Login'
titleColor = 'white'
color = '#BE1E2D'

  />

  </View>
            <View
                style={{
                    marginTop : 20,
                    marginLeft : 50,
                    marginRight : 50,
                borderBottomColor: 'black',
                borderBottomWidth: 1,
            }}
/> 
            <View style = {styles.alignn}>
            <Text style = {styles.creaeAccount}>Need to Create an Account?</Text>
           
            <TouchableOpacity    style = {styles.SignupBtn}
               onPress = {
                  () => this.props.navigation.navigate('Signup')}><Text style={{color:'#BE1E2D'}}> Signup</Text></TouchableOpacity>
                  </View>
            
           

                  </ScrollView>
         
       </View>

       
       
    )
 }
}


const styles = StyleSheet.create({
 container: {
   
 },

username : {
   fontSize : 20,
   marginLeft : 50,
   marginRight : 50,
   marginTop:65,
   
   

   
   
},

password : {
  fontSize : 20,
  marginLeft : 50,
  marginRight : 50,
  marginTop : 20

  
  
},

button : {
marginLeft : 80,
marginRight : 80,
marginTop : 20,
color : 'white',
},
 
   
 
 loginForm:{
     color : '#EF4747',
     fontSize : 35,
     marginLeft : 170,
     marginTop : 25,
     fontFamily:'Helvetica, sans-serif',
     fontWeight:'bold'
     
     

     
 },
 SignupBtn:{
    marginTop:9,

 },

 

 
 creaeAccount:{
        fontSize : 13,
        marginTop : 10,
        marginLeft : 100,
 },
 alignn:{
    flexDirection:'row'
    
 }

 });